import React from 'react';

function Logo(){
  return (
    <>
        <img 
          src="/images/job_penki_ojiisan.png"
          className='img-fluid pb-2'
          style={{ maxWidth: '50%', height: 'auto' }}
        />
        <h1>
          FixItAC++
        </h1>
    </>
  );
}

export default Logo;